# OmbrewBusiness v5.1 – Penyempurnaan database

## Perubahan database
- Room database dinaikkan dari versi 1 ke versi 2 dengan migrasi 1→2; data lama dipertahankan.
- Produk dapat memiliki tabel varian ukuran, dengan harga, resep, hasil resep, dan HPP masing-masing.
- Penjualan menyimpan jumlah pembayaran yang sudah diterima, sisa piutang, varian yang dijual, dan akun penerimaan.
- Transaksi kas memiliki akun terpisah: TUNAI, QRIS, dan BANK.
- Backup/restore mencakup varian dan resep varian serta tetap membaca backup lama.
- Koreksi stok sekarang mewajibkan alasan dan menyimpan alasan di riwayat.
- Penjualan parsial, pencatatan penerimaan piutang sebagian, dan pembatalan mengembalikan kas sesuai jumlah yang benar-benar diterima.
- Ringkasan piutang menghitung sisa tagihan, bukan total transaksi yang belum lunas.

## Catatan tahap
Fondasi skema database dan logika transaksi telah disiapkan. UI pengelolaan ukuran/varian dan input nominal pembayaran sebagian masih perlu disambungkan dan diuji pada perangkat Android. Autentikasi biometrik/PIN dan uji APK final belum termasuk penyelesaian tahap ini. Jangan anggap aplikasi siap produksi sebelum build dan pengujian Android berhasil.

## Build
Gunakan Java 17 dan Gradle 8.7:
`gradle -p OmbrewBusiness-v5.1 assembleDebug`
