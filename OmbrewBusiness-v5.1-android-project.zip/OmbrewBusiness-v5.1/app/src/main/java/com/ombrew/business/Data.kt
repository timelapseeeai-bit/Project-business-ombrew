package com.ombrew.business

import androidx.room.*
import androidx.room.migration.Migration
import kotlinx.coroutines.flow.Flow

@Entity data class Ingredient(@PrimaryKey(autoGenerate=true) val id:Long=0,val name:String,val unit:String,val stock:Double=0.0,val avgCost:Double=0.0,val minStock:Double=0.0)
@Entity data class Product(@PrimaryKey(autoGenerate=true) val id:Long=0,val name:String,val price:Double=0.0,val active:Boolean=true,val useRecipe:Boolean=true,val manualHpp:Double=0.0,val yieldQty:Int=1,val photo:String="")
@Entity(indices=[Index("productId")]) data class RecipeItem(@PrimaryKey(autoGenerate=true) val id:Long=0,val productId:Long,val ingredientId:Long,val qty:Double)
@Entity(indices=[Index("productId")]) data class ProductVariant(@PrimaryKey(autoGenerate=true) val id:Long=0,val productId:Long,val name:String,val price:Double,val active:Boolean=true,val useRecipe:Boolean=true,val manualHpp:Double=0.0,val yieldQty:Int=1)
@Entity(indices=[Index("variantId"),Index("ingredientId")]) data class VariantRecipeItem(@PrimaryKey(autoGenerate=true) val id:Long=0,val variantId:Long,val ingredientId:Long,val qty:Double)
@Entity(indices=[Index("productId"),Index("ts")]) data class Sale(@PrimaryKey(autoGenerate=true) val id:Long=0,val ts:Long,val productId:Long,val productName:String,val qty:Int,val price:Double,val discount:Double,val total:Double,val hpp:Double,val channel:String,val payment:String,val paid:Boolean=true,val status:String="OK",@ColumnInfo(defaultValue="0") val paidAmount:Double=if(paid) total else 0.0,@ColumnInfo(defaultValue="0") val variantId:Long=0,@ColumnInfo(defaultValue="''") val variantName:String="",@ColumnInfo(defaultValue="'TUNAI'") val paymentAccount:String="TUNAI")
@Entity(indices=[Index("ingredientId"),Index("ref")]) data class StockMove(@PrimaryKey(autoGenerate=true) val id:Long=0,val ts:Long,val ingredientId:Long,val delta:Double,val type:String,val value:Double=0.0,val ref:Long=0,val note:String="")
@Entity(indices=[Index("ref"),Index("account"),Index("ts")]) data class CashTx(@PrimaryKey(autoGenerate=true) val id:Long=0,val ts:Long,val type:String,val amount:Double,val note:String="",val ref:Long=0,@ColumnInfo(defaultValue="'TUNAI'") val account:String="TUNAI")

@Dao interface D{
 @Insert(onConflict=OnConflictStrategy.REPLACE) suspend fun put(x:Ingredient):Long
 @Insert(onConflict=OnConflictStrategy.REPLACE) suspend fun put(x:Product):Long
 @Insert(onConflict=OnConflictStrategy.REPLACE) suspend fun put(x:RecipeItem):Long
 @Insert(onConflict=OnConflictStrategy.REPLACE) suspend fun put(x:ProductVariant):Long
 @Insert(onConflict=OnConflictStrategy.REPLACE) suspend fun put(x:VariantRecipeItem):Long
 @Insert(onConflict=OnConflictStrategy.REPLACE) suspend fun put(x:Sale):Long
 @Insert(onConflict=OnConflictStrategy.REPLACE) suspend fun put(x:StockMove):Long
 @Insert(onConflict=OnConflictStrategy.REPLACE) suspend fun put(x:CashTx):Long
 @Query("SELECT * FROM Ingredient ORDER BY name") fun ings():Flow<List<Ingredient>>
 @Query("SELECT * FROM Ingredient WHERE id=:id") suspend fun ing(id:Long):Ingredient?
 @Query("SELECT * FROM Product WHERE id=:id") suspend fun prod(id:Long):Product?
 @Query("SELECT * FROM Product ORDER BY name") fun prods():Flow<List<Product>>
 @Query("SELECT * FROM RecipeItem") fun recipes():Flow<List<RecipeItem>>
 @Query("SELECT * FROM RecipeItem WHERE productId=:p") suspend fun recipe(p:Long):List<RecipeItem>
 @Query("SELECT * FROM ProductVariant WHERE productId=:p ORDER BY id") suspend fun variants(p:Long):List<ProductVariant>
 @Query("SELECT * FROM ProductVariant ORDER BY id") suspend fun allVariants():List<ProductVariant>
 @Query("SELECT * FROM VariantRecipeItem ORDER BY id") suspend fun allVariantRecipes():List<VariantRecipeItem>
 @Query("SELECT * FROM ProductVariant WHERE id=:id") suspend fun variant(id:Long):ProductVariant?
 @Query("SELECT * FROM VariantRecipeItem WHERE variantId=:id") suspend fun variantRecipe(id:Long):List<VariantRecipeItem>
 @Query("DELETE FROM VariantRecipeItem WHERE id=:id") suspend fun delVariantRec(id:Long)
 @Query("DELETE FROM VariantRecipeItem WHERE variantId=:id") suspend fun delVariantRecs(id:Long)
 @Query("DELETE FROM ProductVariant WHERE id=:id") suspend fun delVariant(id:Long)
 @Query("DELETE FROM ProductVariant WHERE productId=:id") suspend fun delVariantsOf(id:Long)
 @Query("DELETE FROM RecipeItem WHERE id=:id") suspend fun delRec(id:Long)
 @Query("DELETE FROM RecipeItem WHERE productId=:p") suspend fun delRecOf(p:Long)
 @Query("SELECT * FROM Sale ORDER BY ts DESC") fun sales():Flow<List<Sale>>
 @Query("SELECT * FROM Sale WHERE id=:id") suspend fun sale(id:Long):Sale?
 @Query("SELECT COUNT(*) FROM Sale WHERE productId=:p") suspend fun salesCount(p:Long):Int
 @Query("DELETE FROM Product WHERE id=:p") suspend fun delProd(p:Long)
 @Query("SELECT COUNT(*) FROM Product") suspend fun nProd():Int
 @Query("SELECT * FROM StockMove ORDER BY ts DESC") fun moves():Flow<List<StockMove>>
 @Query("SELECT * FROM StockMove WHERE ref=:r AND type='JUAL'") suspend fun movesOf(r:Long):List<StockMove>
 @Query("SELECT * FROM CashTx ORDER BY ts DESC") fun cash():Flow<List<CashTx>>
}

@Database(entities=[Ingredient::class,Product::class,RecipeItem::class,ProductVariant::class,VariantRecipeItem::class,Sale::class,StockMove::class,CashTx::class],version=2,exportSchema=false)
abstract class DB:RoomDatabase(){abstract fun d():D
 companion object {
  val MIGRATION_1_2=object:Migration(1,2){
   override fun migrate(db:androidx.sqlite.db.SupportSQLiteDatabase){
    db.execSQL("ALTER TABLE Sale ADD COLUMN paidAmount REAL NOT NULL DEFAULT 0")
    db.execSQL("UPDATE Sale SET paidAmount=CASE WHEN paid=1 THEN total ELSE 0 END")
    db.execSQL("ALTER TABLE Sale ADD COLUMN variantId INTEGER NOT NULL DEFAULT 0")
    db.execSQL("ALTER TABLE Sale ADD COLUMN variantName TEXT NOT NULL DEFAULT ''")
    db.execSQL("ALTER TABLE Sale ADD COLUMN paymentAccount TEXT NOT NULL DEFAULT 'TUNAI'")
    db.execSQL("ALTER TABLE CashTx ADD COLUMN account TEXT NOT NULL DEFAULT 'TUNAI'")
    db.execSQL("CREATE TABLE IF NOT EXISTS ProductVariant (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, productId INTEGER NOT NULL, name TEXT NOT NULL, price REAL NOT NULL, active INTEGER NOT NULL, useRecipe INTEGER NOT NULL, manualHpp REAL NOT NULL, yieldQty INTEGER NOT NULL)")
    db.execSQL("CREATE INDEX IF NOT EXISTS index_ProductVariant_productId ON ProductVariant(productId)")
    db.execSQL("CREATE TABLE IF NOT EXISTS VariantRecipeItem (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, variantId INTEGER NOT NULL, ingredientId INTEGER NOT NULL, qty REAL NOT NULL)")
    db.execSQL("CREATE INDEX IF NOT EXISTS index_VariantRecipeItem_variantId ON VariantRecipeItem(variantId)")
    db.execSQL("CREATE INDEX IF NOT EXISTS index_VariantRecipeItem_ingredientId ON VariantRecipeItem(ingredientId)")
    db.execSQL("CREATE INDEX IF NOT EXISTS index_RecipeItem_productId ON RecipeItem(productId)")
    db.execSQL("CREATE INDEX IF NOT EXISTS index_Sale_productId ON Sale(productId)")
    db.execSQL("CREATE INDEX IF NOT EXISTS index_Sale_ts ON Sale(ts)")
    db.execSQL("CREATE INDEX IF NOT EXISTS index_StockMove_ingredientId ON StockMove(ingredientId)")
    db.execSQL("CREATE INDEX IF NOT EXISTS index_StockMove_ref ON StockMove(ref)")
    db.execSQL("CREATE INDEX IF NOT EXISTS index_CashTx_ref ON CashTx(ref)")
    db.execSQL("CREATE INDEX IF NOT EXISTS index_CashTx_account ON CashTx(account)")
    db.execSQL("CREATE INDEX IF NOT EXISTS index_CashTx_ts ON CashTx(ts)")
   }
  }
 }
}
